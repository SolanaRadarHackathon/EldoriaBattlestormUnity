﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Solana.Unity.Anchor.Models
{
    public class IdlErrorCode
    {
        public uint Code { get; set; }

        public string Name { get; set; }

        public string Msg { get; set; }
    }
}