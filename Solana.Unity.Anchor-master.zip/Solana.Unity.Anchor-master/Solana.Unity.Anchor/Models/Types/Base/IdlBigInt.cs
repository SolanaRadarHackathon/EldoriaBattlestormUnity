﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Solana.Unity.Anchor.Models.Types.Base
{
    public class IdlBigInt : IIdlType
    {
        public string TypeName { get; set; }

    }
}