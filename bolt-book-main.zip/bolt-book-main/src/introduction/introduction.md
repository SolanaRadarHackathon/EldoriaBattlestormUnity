# Introduction

Welcome to The Bolt Book! ⚡

> Bolt is an [open-source project](https://github.com/magicblock-labs/bolt), currently in its early development phase, and warmly welcomes contributors. For additional resources, join the community on [Discord](https://discord.com/invite/MBkdC3gxcv).

This chapter covers what bolt is, how its documentation is structured, and what you should know to have a good time with this guide.

If you find errors or something doesn't work, please report it [here](https://github.com/magicblock-labs/bolt-book/issues).
