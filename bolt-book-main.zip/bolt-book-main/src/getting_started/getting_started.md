# Getting Started

This chapter walks you through the installation process and the folder structure of an anchor workspace.