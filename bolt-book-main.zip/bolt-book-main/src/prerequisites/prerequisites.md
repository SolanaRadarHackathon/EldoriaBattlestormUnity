# Prerequisites

This chapter provides you with the necessary background knowledge to get started with bolt.
