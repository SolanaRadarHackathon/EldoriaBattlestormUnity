﻿using System;
using System.Net.WebSockets;
using System.Threading;
using System.Threading.Tasks;

namespace Solana.Unity.Rpc.Core.Sockets
{
    internal interface IWebSocket : IDisposable
    {
        WebSocketState State { get; }
        string CloseStatusDescription { get; }
        WebSocketCloseStatus? CloseStatus { get; }
        Task ConnectAsync(Uri uri, CancellationToken cancellationToken);
        Task CloseAsync(CancellationToken cancellationToken);
        Task SendAsync(ReadOnlyMemory<byte> buffer, WebSocketMessageType messageType, bool endOfMessage, CancellationToken cancellationToken);
        Task CloseAsync(WebSocketCloseStatus closeStatus, string statusDescription, CancellationToken cancellationToken);

        public abstract event WebSocketMessageEventHandler OnMessage;
        public delegate void WebSocketMessageEventHandler(byte[] data);
        public event EventHandler<WebSocketState> ConnectionStateChangedEvent;
    }
}