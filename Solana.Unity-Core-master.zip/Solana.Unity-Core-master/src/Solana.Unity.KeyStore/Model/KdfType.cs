namespace Solana.Unity.KeyStore.Model
{
    public enum KdfType
    {
        Scrypt,
        Pbkdf2
    }
}