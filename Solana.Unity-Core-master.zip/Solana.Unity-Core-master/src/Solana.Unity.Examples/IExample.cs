﻿using System.Threading.Tasks;

namespace Solana.Unity.Examples
{
    interface IExample
    {
        void Run();
    }
}