﻿using Solana.Unity.Extensions;
using Solana.Unity.Extensions.Models.TokenMint;
using Solana.Unity.Rpc;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace Solana.Unity.Examples
{
    public class TokenWalletExample : IExample
    {

        private static readonly IRpcClient RpcClient = ClientFactory.GetClient(Cluster.TestNet);

        private const string MnemonicWords =
            "route clerk disease box emerge airport loud waste attitude film army tray " +
            "forward deal onion eight catalog surface unit card window walnut wealth medal";

        public async void Run()
        {

            Wallet.Wallet wallet = new Wallet.Wallet(MnemonicWords);
            Wallet.Account ownerAccount = wallet.GetAccount(10);

            // add TokenDef for a TestNet minted token created by Solana.Unity examples
            var tokens = new TokenMintResolver();
            tokens.Add(new TokenDef("AHRNasvVB8UDkU9knqPcn4aVfRbnbVC9HJgSTBwbx8re", "Solnet Test Token", "STT", 2));

            // load snapshot of wallet and sub-accounts
            TokenWallet tokenWallet = await TokenWallet.LoadAsync(RpcClient, tokens, ownerAccount);
            var balances = tokenWallet.Balances();
            var maxsym = balances.Max(x => x.Symbol.Length);
            var maxname = balances.Max(x => x.TokenName.Length);

            // show individual token accounts
            Console.WriteLine("Individual Accounts...");
            foreach (var account in tokenWallet.TokenAccounts())
            {
                Console.WriteLine($"{account.Symbol.PadRight(maxsym)} {account.QuantityDecimal,14} {account.TokenName.PadRight(maxname)} {account.PublicKey} {(account.IsAssociatedTokenAccount ? "[ATA]" : "")}");
            }
            Console.WriteLine();

            // show filtered accounts
            Console.WriteLine("Filtered Accounts...");
            var sublist = tokenWallet.TokenAccounts().WithSymbol("STT").WithMint("AHRNasvVB8UDkU9knqPcn4aVfRbnbVC9HJgSTBwbx8re");
            foreach (var account in sublist)
            {
                Console.WriteLine($"{account.Symbol.PadRight(maxsym)} {account.QuantityDecimal,14} {account.TokenName.PadRight(maxname)} {account.PublicKey} {(account.IsAssociatedTokenAccount ? "[ATA]" : "")}");
            }
            Console.WriteLine();

            // show consolidated balances
            Console.WriteLine("Consolidated Balances...");
            foreach (var balance in tokenWallet.Balances())
            {
                Console.WriteLine($"{balance.Symbol.PadRight(maxsym)} {balance.QuantityDecimal,14} {balance.TokenName.PadRight(maxname)} in {balance.AccountCount} {(balance.AccountCount == 1 ? "account" : "accounts")}");
            }
            Console.WriteLine();

        }
    }
}