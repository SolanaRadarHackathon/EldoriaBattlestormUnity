namespace Solana.Unity.Dex.Models;

/// <summary>
/// Token list type, strict or all.
/// </summary>
public enum TokenListType
{
    Strict,
    All
}