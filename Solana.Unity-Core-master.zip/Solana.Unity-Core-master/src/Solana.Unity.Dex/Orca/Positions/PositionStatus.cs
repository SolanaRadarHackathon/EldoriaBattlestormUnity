namespace Solana.Unity.Dex.Orca.Positions
{
    public enum PositionStatus
    {
        BelowRange, 
        InRange, 
        AboveRange
    }
}